<?php $__env->startSection('content'); ?>
<body  style="background:grey">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">DIGITAL+</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <a href="<?php echo e(route('canalsCreate')); ?>"><button type="button" class="btn btn-dark">Crear Canal</button></a>
                    <a href="<?php echo e(route('programasCreate')); ?>"><button type="button" class="btn btn-dark">Crear Programa</button></a>
                    <a href="<?php echo e(route('graellasCreate')); ?>"><button type="button" class="btn btn-dark">Crear Graella</button></a>

                    <a href="<?php echo e(route('canalsEdit')); ?>"><button type="button" class="btn btn-dark">Edita Canal</button></a>
                    <a href="<?php echo e(route('GraellaIndex')); ?>"><button type="button" class="btn btn-dark">Veure Graella</button></a>
                 
              
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/joseHttp-master/resources/views/home.blade.php ENDPATH**/ ?>