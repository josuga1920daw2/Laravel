<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body>
<a href="<?php echo e(route('home')); ?>"><button style="margin: 2px" class="btn-dark btn btn-primary">Volver</button></a>

<table class="table">
    <thead class="thead-dark">
        <tr>
            <th>Código</th>
            <th>Canal</th>
            <th>Programa</td>
            <th>Dia</th>
            <th>Hora</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $graellas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graella): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <tr>
    <th><?php echo e($graella -> id); ?></th>
    <th>
    <?php $__currentLoopData = $graella->programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php $__currentLoopData = $canals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($programa->idCanal == $canal->id): ?>
                <?php echo e($canal->nameCanal); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </th>
    <th>
    <?php $__currentLoopData = $graella->programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <?php echo e($programa->namePrograma); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </th>

    <th><?php echo e($graella -> diaCanal); ?></th>
    <th><?php echo e($graella -> horaCanal); ?></th>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</body>

<?php /**PATH /var/www/html/joseHttp-master/resources/views/graellas/index.blade.php ENDPATH**/ ?>