<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body style="background:grey">
    <a href="<?php echo e(route('home')); ?>"><button style="margin: 2px" class="btn-dark btn btn-primary">Volver</button></a>
    
    <form method="GET" action="<?php echo e(route('programasStore')); ?>">
    
    <div style="margin:6px" class="form-group mr-4 ml-4">
        <label for='namePrograma'>Nombre Programa</label>
        <input class="form-control" name="namePrograma" type="text"> <br>
    </div>

    <div class="form-group mr-4 ml-4">
        <label for='descripcio'>Descripción</label>
        <input class="form-control" name="descripcio" type="text"> 
    </div>

    <div class="form-group col-5">
        <label for='tipo'>Tipo</label> 
        <select class="btn btn-info dropdown-toggle" name="tipo">
            <option  value="Deportivo">Deporte </option>
            <option selected="Documental">Documental</option>
            <option value ="Entretenimiento">Entretenimiento</option>
            <option  value ="Romantica">Romatica</option>
            <option  value ="Miedo">Miedo</option>
        </select>
    </div> 

    <div class="form-group col-5">
        <label for='clasificacion'>Clasificacion</label>
        <select  class="btn btn-info dropdown-toggle" name="clasificacion">
                <option selected="0" value="0">Todos los Publico</option>
                <option value="mas3">+3</option>
                <option value="mas7">+7</option>
                <option value="mas13">+13</option>
                <option value="mas18">+18</option>
            </select>
    </div>

    <div class="form-group col-5">
    <label for='idCanal'>idCanal</label>
    <select class="btn btn-info dropdown-toggle" name='idCanal'> 
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($user->id); ?>'><?php echo e($user-> nameCanal); ?></option>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>

    <button style="margin:15px" class="btn-dark btn btn-primary" type="submit" value="Enviar">Crear Programa </button> 
    
  
   </form>
</body>
<?php /**PATH /var/www/html/joseHttp-master/resources/views/programas/create.blade.php ENDPATH**/ ?>