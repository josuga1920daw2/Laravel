<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body style="background:grey">
<a href="<?php echo e(route('home')); ?>"><button style="margin: 2px" class="btn-dark btn-lg">Volver</button></a>
<div>
    <br>
    <h2 style="text-align:center;">Editar un canal</h3>
    <?php if(count($errors) > 0): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form style="margin-left:10px;" method="get" action="<?php echo e(action('CanalController@update')); ?>">
        <?php echo e(csrf_field()); ?>

        
        <h4>Canal a Renombrar:
        <select class="btn btn-info dropdown-toggle" name="id"> 
            <?php $__currentLoopData = $idCanales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($idC-> id); ?>"><?php echo e($idC-> nameCanal); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></h4><br><br>

        <h4>Nuevo Nombre Para el Canal:</h4>
        <input class="form-control col-6" type="text"  name="nameCanal"  placeholder="Escribe el nombre..." /><br>
       
        <button class="btn-dark btn-lg " type="submit" value="Editar">Modificar Canal </button>
       
    </form>
</div>
</body><?php /**PATH /var/www/html/joseHttp-master/resources/views/canals/edit.blade.php ENDPATH**/ ?>