<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body style="background:grey">
<a href="<?php echo e(route('home')); ?>"><button style="margin: 2px" class="btn-dark btn btn-primary">Volver</button></a>

    <form method="GET" action="<?php echo e(route('graellaStore')); ?>">

<div style="margin:6px" class="form-group mr-4 ml-4">
    <label for='nameCanal'>Canal</label>
    <select  class="btn btn-info dropdown-toggle" name='nameCanal'> 
        <?php $__currentLoopData = $usersCanal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($user->id); ?>'><?php echo e($user-> nameCanal); ?></option>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div style="margin:6px" class="form-group mr-4 ml-4">
    <label for='namePrograma'>Programa</label>
    <select  class="btn btn-info dropdown-toggle"  name='namePrograma'> 
        <?php $__currentLoopData = $usersProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($user->id); ?>'><?php echo e($user-> namePrograma); ?></option>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>      
<div style="margin:6px" class="form-group col-2">
        <label for='horaCanal'>Hora</label>
        <input class="form-control" name="horaCanal" type="time"> 
</div> 
<div style="margin:6px" class="form-group col-3">
        <label for='diaCanal'>Día</label>
        <input class="form-control" name="diaCanal" type="date"> 
</div> 
 
 <button style="margin:15px" class="btn-dark btn btn-primary" type="submit" value="Enviar">Crear Graella </button>  
    </form>
</body><?php /**PATH /var/www/html/joseHttp-master/resources/views/graellas/create.blade.php ENDPATH**/ ?>