<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Graella extends Model
{ 
    protected $fillable = [
        "diaCanal",
        "horaCanal"
    ];


    public function programas()
    {
        return $this->belongsToMany('App\Programa');
    }  
}
