<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>

<body style="background:grey">
<a href="{{route('home')}}"><button style="margin: 2px" class="btn-dark btn-lg">Volver</button></a>
<div>
    <br>
    <h2 style="text-align:center;">Editar un canal</h3>
    @if(count($errors) > 0)
        <div>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form style="margin-left:10px;" method="get" action="{{action('CanalController@update')}}">
        {{csrf_field()}}
        
        <h4>Canal a Renombrar:
        <select class="btn btn-info dropdown-toggle" name="id"> 
            @foreach($idCanales as $idC)
                <option value="{{$idC-> id}}">{{$idC-> nameCanal}}</option>
            @endforeach
        </select></h4><br><br>

        <h4>Nuevo Nombre Para el Canal:</h4>
        <input class="form-control col-6" type="text"  name="nameCanal"  placeholder="Escribe el nombre..." /><br>
       
        <button class="btn-dark btn-lg " type="submit" value="Editar">Modificar Canal </button>
       
    </form>
</div>
</body>