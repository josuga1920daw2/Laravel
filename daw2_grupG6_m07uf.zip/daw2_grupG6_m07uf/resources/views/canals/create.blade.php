<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body style="background:grey">

<a href="{{route('home')}}"><button style="margin: 2px" class="btn-dark btn btn-primary">Volver</button></a>

<form method="GET" action="{{route('canalsStore')}}">
<div style="margin:6px" class="form-group mr-4 ml-4">
    <label for='nameCanal'>Nombre Canal</label>
    <input name="nameCanal" type="text"> 
 </div> 
 <button style="margin:15px" class="btn-dark btn btn-primary" type="submit" value="Enviar">Crear Canal </button> 
   
</form>
</body>