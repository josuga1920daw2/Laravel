@extends('layouts.app')

@section('content')
<body  style="background:grey">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">DIGITAL+</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <a href="{{route('canalsCreate')}}"><button type="button" class="btn btn-dark">Crear Canal</button></a>
                    <a href="{{route('programasCreate')}}"><button type="button" class="btn btn-dark">Crear Programa</button></a>
                    <a href="{{route('graellasCreate')}}"><button type="button" class="btn btn-dark">Crear Graella</button></a>

                    <a href="{{route('canalsEdit')}}"><button type="button" class="btn btn-dark">Edita Canal</button></a>
                    <a href="{{route('GraellaIndex')}}"><button type="button" class="btn btn-dark">Veure Graella</button></a>
                 
              
                </div>
            </div>
        </div>
    </div>
</div>
</body>
@endsection
